import asyncio
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
import openpyxl
import os
from datetime import datetime
import json

# ==============================
# 🔧 НАСТРОЙКИ замени на свои
# ==============================

BOT_TOKEN = "" # замени на своего бота получить в @BotFather

ADMINS = [1234456475]  # ID админов (только принимают заявки) (замени на свой или админа получить в @uid_info_robot)
RECIPIENTS = [1234456475]  # Кто получает уведомления (замени на свой или админа получить в @uid_info_robot)

FIELDS = [
    ("Как вас зовут?", True, "👤", "Имя"),
    ("Ваш номер телефона?", True, "📞", "Телефон"),
    ("Сколько лет стажу?", False, "💼", "Стаж"),
    ("Где работали ранее?", False, "🏢", "Предыдущее место работы"),
    ("Комментарий?", True, "💬", "Комментарий"),
]

# ==============================
# 🗃 БАЗА ДАННЫХ (JSON) не трогай
# ==============================

APPLICATIONS_FILE = "applications.json"
PENDING = "pending"
APPROVED = "approved"
REJECTED = "rejected"

def load_applications():
    if not os.path.exists(APPLICATIONS_FILE):
        return []
    with open(APPLICATIONS_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_applications(applications):
    with open(APPLICATIONS_FILE, 'w', encoding='utf-8') as f:
        json.dump(applications, f, ensure_ascii=False, indent=2)

def add_application(user_id, username, answers):
    applications = load_applications()
    application = {
        "id": len(applications) + 1,
        "user_id": user_id,
        "username": username or "Без username",
        "answers": answers,
        "status": PENDING,
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    applications.append(application)
    save_applications(applications)
    return application

def update_application_status(app_id, status):
    applications = load_applications()
    for app in applications:
        if app["id"] == app_id:
            app["status"] = status
            break
    save_applications(applications)

def get_pending_applications():
    return [app for app in load_applications() if app["status"] == PENDING]

def get_application_by_id(app_id):
    applications = load_applications()
    for app in applications:
        if app["id"] == app_id:
            return app
    return None

# ==============================
# 🤖 FSM (машина состояний)
# ==============================

class ApplicationState(StatesGroup):
    waiting_answer = State()
    confirming_single = State()
    confirming_final = State()

# ==============================
# 🛠 УТИЛИТЫ
# ==============================

storage = MemoryStorage()
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=storage)

user_data = {}

def get_active_fields():
    return [(q, e, name) for q, enabled, e, name in FIELDS if enabled]

# Создаём Excel при старте
EXCEL_FILE = "заявки.xlsx"
if not os.path.exists(EXCEL_FILE):
    wb = openpyxl.Workbook()
    ws = wb.active
    headers = ["Дата"] + [name for _, _, name in get_active_fields()] + ["Статус"]
    ws.append(headers)
    wb.save(EXCEL_FILE)

def get_single_confirmation_kb():
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Далее", callback_data="next"),
            InlineKeyboardButton(text="✏️ Изменить", callback_data="change")
        ]
    ])
    return kb

def get_final_confirmation_kb():
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Отправить", callback_data="send"),
            InlineKeyboardButton(text="✏️ Перезаполнить", callback_data="restart")
        ]
    ])
    return kb

def get_application_kb(application, current_index=0, total=0):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Принять", callback_data=f"approve_{application['id']}"),
            InlineKeyboardButton(text="❌ Отклонить", callback_data=f"reject_{application['id']}")
        ],
        [
            InlineKeyboardButton(text="⬅️ Назад", callback_data=f"prev_{application['id']}"),
            InlineKeyboardButton(text=f"{current_index + 1}/{total}", callback_data="none"),
            InlineKeyboardButton(text="➡️ Вперед", callback_data=f"next_{application['id']}")
        ]
    ])
    return kb

# ==============================
# 🚀 ОБРАБОТЧИКИ ДЛЯ ПОЛЬЗОВАТЕЛЕЙ
# ==============================

@dp.message(Command("start", "заявка"))
async def start_app(message: types.Message, state: FSMContext):
    # Админы не могут оставлять заявки
    if message.from_user.id in ADMINS:
        await message.answer("👋 Вы администратор! Используйте /list для просмотра заявок")
        return

    fields = get_active_fields()
    if not fields:
        await message.answer("❌ Заявка отключена.")
        return

    user_data[message.from_user.id] = {
        "step": 0,
        "answers": [],
        "current_answer": "",
        "messages_to_delete": []
    }

    await state.set_state(ApplicationState.waiting_answer)
    await ask_question(message.from_user.id, state)

async def ask_question(user_id: int, state: FSMContext):
    fields = get_active_fields()
    user_info = user_data[user_id]
    step = user_info["step"]

    if step >= len(fields):
        await state.set_state(ApplicationState.confirming_final)
        await show_final_confirmation(user_id, state)
        return

    question = fields[step][0]
    emoji = fields[step][1]

    msg = await bot.send_message(user_id, f"{emoji} {question}")
    user_info["messages_to_delete"].append(msg.message_id)

    await state.set_state(ApplicationState.waiting_answer)

async def show_single_confirmation(user_id: int, state: FSMContext):
    """Показывает подтверждение для одного ответа"""
    fields = get_active_fields()
    user_info = user_data[user_id]
    step = user_info["step"]
    current_answer = user_info["current_answer"]

    if step >= len(fields):
        return

    field_name = fields[step][2]
    emoji = fields[step][1]

    text = f"📋 Проверьте ответ:\n\n{emoji} {field_name}: <code>{current_answer}</code>"

    # Удаляем предыдущие сообщения
    for msg_id in user_info["messages_to_delete"]:
        try:
            await bot.delete_message(user_id, msg_id)
        except:
            pass

    user_info["messages_to_delete"] = []

    msg = await bot.send_message(user_id, text, reply_markup=get_single_confirmation_kb(), parse_mode="HTML")
    user_info["messages_to_delete"].append(msg.message_id)

    await state.set_state(ApplicationState.confirming_single)

async def show_final_confirmation(user_id: int, state: FSMContext):
    """Показывает финальное подтверждение всей заявки"""
    user_info = user_data[user_id]
    fields = get_active_fields()

    text = "✅ Проверьте всю заявку:\n\n"
    for i, (_, emoji, name) in enumerate(fields):
        ans = user_info["answers"][i] if i < len(user_info["answers"]) else "—"
        text += f"{emoji} {name}: <code>{ans}</code>\n"

    text += "\nВсё верно?"

    # Удаляем предыдущие сообщения
    for msg_id in user_info["messages_to_delete"]:
        try:
            await bot.delete_message(user_id, msg_id)
        except:
            pass

    user_info["messages_to_delete"] = []

    msg = await bot.send_message(user_id, text, reply_markup=get_final_confirmation_kb(), parse_mode="HTML")
    user_info["messages_to_delete"].append(msg.message_id)

@dp.message(ApplicationState.waiting_answer)
async def handle_answer(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    if user_id not in user_data:
        return

    user_data[user_id]["current_answer"] = message.text

    # Удаляем сообщение пользователя для чистоты
    try:
        await message.delete()
    except:
        pass

    await state.set_state(ApplicationState.confirming_single)
    await show_single_confirmation(user_id, state)

@dp.callback_query(F.data.in_(["next", "change", "send", "restart"]))
async def handle_callback(callback: types.CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    if user_id not in user_data:
        return

    await callback.answer()

    user_info = user_data[user_id]
    fields = get_active_fields()

    if callback.data == "next":
        # Сохраняем текущий ответ и переходим к следующему вопросу
        user_info["answers"].append(user_info["current_answer"])
        user_info["step"] += 1
        user_info["current_answer"] = ""

        # Удаляем сообщение с кнопками
        try:
            await callback.message.delete()
        except:
            pass

        user_info["messages_to_delete"] = []
        await state.set_state(ApplicationState.waiting_answer)
        await ask_question(user_id, state)

    elif callback.data == "change":
        # Возвращаемся к редактированию текущего вопроса
        user_info["current_answer"] = ""

        # Удаляем сообщение с кнопками
        try:
            await callback.message.delete()
        except:
            pass

        user_info["messages_to_delete"] = []
        await state.set_state(ApplicationState.waiting_answer)
        await ask_question(user_id, state)

    elif callback.data == "send":
        # Отправляем заявку
        await save_and_send(user_id, callback.from_user.username or callback.from_user.first_name)
        await callback.message.edit_text("🎉 Заявка отправлена! Ожидайте ответа администратора.")
        user_data.pop(user_id, None)
        await state.clear()

    elif callback.data == "restart":
        # Начинаем заново
        user_data[user_id] = {
            "step": 0,
            "answers": [],
            "current_answer": "",
            "messages_to_delete": []
        }
        await callback.message.edit_text("🔄 Начинаем заново...")
        await state.set_state(ApplicationState.waiting_answer)
        await ask_question(user_id, state)

async def save_and_send(user_id: int, username: str):
    user_info = user_data[user_id]
    fields = get_active_fields()
    answers = user_info["answers"]

    # Сохраняем в JSON
    application = add_application(user_id, username, answers)

    # Сохраняем в Excel
    wb = openpyxl.load_workbook(EXCEL_FILE)
    ws = wb.active
    row = [datetime.now().strftime("%Y-%m-%d %H:%M")] + answers + ["В ожидании"]
    ws.append(row)
    wb.save(EXCEL_FILE)

    # Формируем красивое сообщение для админов
    msg = "🔔 <b>Новая заявка!</b>\n\n"
    for i, (_, emoji, name) in enumerate(fields):
        ans = answers[i]
        msg += f"{emoji} {name}: <code>{ans}</code>\n"

    msg += f"\n👤 От: {username}"
    msg += f"\n🆔 ID: {user_id}"
    msg += f"\n📅 {datetime.now().strftime('%d.%m.%Y %H:%M')}"
    msg += f"\n\n🎯 Статус: <b>В ожидании</b>"

    # Отправляем всем админам
    for admin_id in ADMINS:
        try:
            pending_apps = get_pending_applications()
            current_index = next((i for i, app in enumerate(pending_apps) if app["id"] == application["id"]), 0)

            await bot.send_message(
                admin_id,
                msg,
                reply_markup=get_application_kb(application, current_index, len(pending_apps)),
                parse_mode="HTML"
            )
        except Exception as e:
            print(f"Ошибка отправки админу {admin_id}: {e}")

# ==============================
# 🛠 ОБРАБОТЧИКИ ДЛЯ АДМИНОВ
# ==============================

@dp.message(Command("list"))
async def show_applications_list(message: types.Message):
    if message.from_user.id not in ADMINS:
        await message.answer("❌ У вас нет прав для просмотра заявок")
        return

    pending_apps = get_pending_applications()

    if not pending_apps:
        await message.answer("📭 Нет заявок в ожидании")
        return

    # Показываем первую заявку
    application = pending_apps[0]
    await show_application_message(message.from_user.id, application, 0, len(pending_apps))

async def show_application_message(admin_id: int, application: dict, current_index: int, total: int):
    fields = get_active_fields()

    msg = "📋 <b>Заявка #{}</b>\n\n".format(application["id"])
    for i, (_, emoji, name) in enumerate(fields):
        ans = application["answers"][i] if i < len(application["answers"]) else "—"
        msg += f"{emoji} {name}: <code>{ans}</code>\n"

    msg += f"\n👤 От: {application['username']}"
    msg += f"\n🆔 ID: {application['user_id']}"
    msg += f"\n📅 {application['date']}"
    msg += f"\n\n🎯 Статус: <b>В ожидании</b>"

    await bot.send_message(
        admin_id,
        msg,
        reply_markup=get_application_kb(application, current_index, total),
        parse_mode="HTML"
    )

@dp.callback_query(F.data.startswith(("approve_", "reject_", "prev_", "next_")))
async def handle_admin_actions(callback: types.CallbackQuery):
    if callback.from_user.id not in ADMINS:
        await callback.answer("❌ У вас нет прав", show_alert=True)
        return

    data = callback.data
    await callback.answer()

    if data.startswith("approve_"):
        app_id = int(data.split("_")[1])
        application = get_application_by_id(app_id)

        if application:
            update_application_status(app_id, APPROVED)

            # Уведомляем пользователя
            try:
                await bot.send_message(
                    application["user_id"],
                    "🎉 Ваша заявка одобрена! С вами свяжутся в ближайшее время."
                )
            except:
                pass

            # Обновляем Excel
            wb = openpyxl.load_workbook(EXCEL_FILE)
            ws = wb.active
            for row in range(2, ws.max_row + 1):
                if ws.cell(row, 1).value == application["date"]:
                    ws.cell(row, len(get_active_fields()) + 2).value = "Одобрено"
                    break
            wb.save(EXCEL_FILE)

            await callback.message.edit_text(
                f"✅ Заявка #{app_id} одобрена!\nПользователь уведомлен.",
                reply_markup=None
            )

    elif data.startswith("reject_"):
        app_id = int(data.split("_")[1])
        application = get_application_by_id(app_id)

        if application:
            update_application_status(app_id, REJECTED)

            # Уведомляем пользователя
            try:
                await bot.send_message(
                    application["user_id"],
                    "❌ К сожалению, ваша заявка отклонена. Мы не можем вас принять в данный момент."
                )
            except:
                pass

            # Обновляем Excel
            wb = openpyxl.load_workbook(EXCEL_FILE)
            ws = wb.active
            for row in range(2, ws.max_row + 1):
                if ws.cell(row, 1).value == application["date"]:
                    ws.cell(row, len(get_active_fields()) + 2).value = "Отклонено"
                    break
            wb.save(EXCEL_FILE)

            await callback.message.edit_text(
                f"❌ Заявка #{app_id} отклонена!\nПользователь уведомлен.",
                reply_markup=None
            )

    elif data.startswith("prev_") or data.startswith("next_"):
        app_id = int(data.split("_")[1])
        pending_apps = get_pending_applications()

        if not pending_apps:
            await callback.message.edit_text("📭 Нет заявок в ожидании")
            return

        current_index = next((i for i, app in enumerate(pending_apps) if app["id"] == app_id), 0)

        if data.startswith("prev_"):
            new_index = (current_index - 1) % len(pending_apps)
        else:  # next_
            new_index = (current_index + 1) % len(pending_apps)

        application = pending_apps[new_index]
        await callback.message.edit_text(
            callback.message.html_text,
            reply_markup=get_application_kb(application, new_index, len(pending_apps)),
            parse_mode="HTML"
        )

# ==============================
# 🚀 ЗАПУСК
# ==============================

async def main():
    print("🚀 Бот запущен на aiogram!")
    print("✅ Excel файл готов")
    print("✅ JSON база данных готова")
    print("📋 Активные поля:", [name for _, _, name in get_active_fields()])
    print("👑 Админы:", ADMINS)
    print("👥 Получатели:", RECIPIENTS)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())