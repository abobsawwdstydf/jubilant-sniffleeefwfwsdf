import os
import json
import sqlite3
import logging
import html
import random
import string
import asyncio
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

BOT_TOKEN = ""
TECH_ADMIN_ID =
CHANNEL_ID = ""
DATA_DIR = "data"
CONFIG_DIR = "config"
USERS_DIR = os.path.join(DATA_DIR, "users")
DB_PATH = os.path.join(DATA_DIR, "main.db")
LOG_PATH = os.path.join(DATA_DIR, "bot.log")
START_IMAGE_URL = "https://www.darkheavens.ru/photo_5404333992980905422_y.jpg"
BOT_TITLE = "Подслушано"

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(CONFIG_DIR, exist_ok=True)
os.makedirs(USERS_DIR, exist_ok=True)

class MagentaFormatter(logging.Formatter):
    def format(self, record):
        MAGENTA = "\033[95m"
        RESET = "\033[0m"
        return f"{MAGENTA}{super().format(record)}{RESET}"

logger = logging.getLogger("predloshka")
logger.setLevel(logging.INFO)
fh = logging.FileHandler(LOG_PATH, encoding="utf-8")
fh.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
sh = logging.StreamHandler()
sh.setFormatter(MagentaFormatter("%(asctime)s | %(levelname)s | %(message)s"))
logger.addHandler(fh)
logger.addHandler(sh)

bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(storage=storage)

class States(StatesGroup):
    waiting_for_category = State()
    waiting_for_text = State()
    waiting_for_media = State()
    waiting_for_confirm = State()
    waiting_for_schedule = State()
    users_wait_ban_duration = State()

ROLE_LIMITS = {"default": 10, "trainee": 15, "moderator": 25, "admin": None, "tech_admin": None}
ROLE_BADGES = {"default": "Пользователь", "trainee": "Стажёр", "moderator": "Модератор", "admin": "Админ", "tech_admin": "ТехАдмин"}
CATEGORIES = [
    ("question", "❓ Вопрос"),
    ("complaint", "🚨 Жалоба"),
    ("suggestion", "💡 Предложение"),
    ("lost_found", "🔍 Потеряшка"),
    ("urgent", "🚨 СРОЧНОЕ"),
    ("announce", "🧾 Анонс"),
    ("other", "📌 Другое"),
    ("extra", "✨ Доп. категория")
]

def gen_fake_name() -> str:
    return "".join(random.choice(string.ascii_lowercase) for _ in range(6))

def user_file(uid:int) -> str:
    return os.path.join(USERS_DIR, f"{uid}.json")

def ensure_user_file(uid:int, tg_user: types.User):
    path = user_file(uid)
    if not os.path.exists(path):
        d = {"real_name": getattr(tg_user, "full_name", tg_user.username or str(uid)), "fake_name": gen_fake_name(), "role": "default", "posts": []}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
    else:
        try:
            data = json.load(open(path, "r", encoding="utf-8"))
        except Exception:
            data = {}
        changed = False
        if "real_name" not in data:
            data["real_name"] = getattr(tg_user, "full_name", tg_user.username or str(uid)); changed = True
        if "fake_name" not in data or not data.get("fake_name"):
            data["fake_name"] = gen_fake_name(); changed = True
        if "role" not in data:
            data["role"] = "default"; changed = True
        if "posts" not in data:
            data["posts"] = []; changed = True
        if changed:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)

def read_user(uid:int) -> Dict[str,Any]:
    path = user_file(uid)
    if not os.path.exists(path):
        return {}
    try:
        return json.load(open(path, "r", encoding="utf-8"))
    except Exception:
        logger.exception("read_user")
        return {}

def write_user(uid:int, data:Dict[str,Any]):
    with open(user_file(uid), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def add_post_to_user(uid:int, pid:int):
    uf = read_user(uid) or {"real_name": str(uid), "fake_name": gen_fake_name(), "role": "default", "posts": []}
    posts = uf.get("posts", [])
    posts.insert(0, pid)
    uf["posts"] = posts
    write_user(uid, uf)

def migrate_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS admins (
        user_id INTEGER PRIMARY KEY,
        rank TEXT DEFAULT 'default',
        appointed_by INTEGER,
        appointed_at TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        category TEXT,
        text TEXT,
        photo TEXT,
        video TEXT,
        status TEXT DEFAULT 'pending',
        created_at TEXT,
        scheduled_at TEXT,
        moderated_by INTEGER,
        moderated_at TEXT,
        channel_message_id INTEGER,
        is_urgent INTEGER DEFAULT 0,
        needs_moderation INTEGER DEFAULT 1
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS bans (
        user_id INTEGER PRIMARY KEY,
        banned_by INTEGER,
        reason TEXT,
        until_ts TEXT,
        created_at TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS user_limits (
        user_id INTEGER,
        date TEXT,
        count INTEGER DEFAULT 0,
        PRIMARY KEY (user_id, date)
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS mod_messages (
        post_id INTEGER,
        chat_id INTEGER,
        message_id INTEGER
    )""")
    conn.commit()
    cur.execute("PRAGMA table_info(posts)")
    cols = [r[1] for r in cur.fetchall()]
    if "animation" not in cols:
        try:
            cur.execute("ALTER TABLE posts ADD COLUMN animation TEXT")
        except Exception:
            pass
    if "is_urgent" not in cols:
        try:
            cur.execute("ALTER TABLE posts ADD COLUMN is_urgent INTEGER DEFAULT 0")
        except Exception:
            pass
    if "needs_moderation" not in cols:
        try:
            cur.execute("ALTER TABLE posts ADD COLUMN needs_moderation INTEGER DEFAULT 1")
        except Exception:
            pass
    cur.execute("PRAGMA table_info(bans)")
    bans_cols = [r[1] for r in cur.fetchall()]
    if "prev_role" not in bans_cols:
        try:
            cur.execute("ALTER TABLE bans ADD COLUMN prev_role TEXT")
        except Exception:
            pass
    conn.commit()
    conn.close()

migrate_db()

def get_role(uid:int) -> str:
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT rank FROM admins WHERE user_id = ?", (uid,))
        r = cur.fetchone()
        conn.close()
        if r and r[0]:
            return r[0]
    except Exception:
        logger.exception("get_role")
    uf = read_user(uid)
    return uf.get("role", "default") if uf else "default"

def set_role(uid:int, role:str, appointed_by:int=0):
    uf = read_user(uid) or {"real_name": str(uid), "fake_name": gen_fake_name(), "role": role, "posts": []}
    uf["role"] = role
    if role != "default" and not uf.get("fake_name"):
        uf["fake_name"] = gen_fake_name()
    write_user(uid, uf)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO admins (user_id, rank, appointed_by, appointed_at) VALUES (?, ?, ?, ?)", (uid, role, appointed_by, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def list_admin_ids() -> List[int]:
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM admins")
        rows = [r[0] for r in cur.fetchall()]
        conn.close()
        return rows
    except Exception:
        logger.exception("list_admin_ids")
        return []

def user_daily_count(uid:int) -> int:
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        today = datetime.now().strftime("%Y-%m-%d")
        cur.execute("SELECT count FROM user_limits WHERE user_id = ? AND date = ?", (uid, today))
        r = cur.fetchone()
        conn.close()
        return r[0] if r else 0
    except Exception:
        logger.exception("user_daily_count")
        return 0

def increment_user_daily(uid:int):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        today = datetime.now().strftime("%Y-%m-%d")
        cur.execute("INSERT INTO user_limits (user_id, date, count) VALUES (?, ?, 1) ON CONFLICT(user_id, date) DO UPDATE SET count = count + 1", (uid, today))
        conn.commit()
        conn.close()
    except Exception:
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            today = datetime.now().strftime("%Y-%m-%d")
            cur.execute("SELECT count FROM user_limits WHERE user_id = ? AND date = ?", (uid, today))
            r = cur.fetchone()
            if r:
                cur.execute("UPDATE user_limits SET count = count + 1 WHERE user_id = ? AND date = ?", (uid, today))
            else:
                cur.execute("INSERT INTO user_limits (user_id, date, count) VALUES (?, ?, 1)", (uid, today))
            conn.commit()
            conn.close()
        except Exception:
            logger.exception("increment_user_daily fallback2")

def allowed_to_post(uid:int) -> Tuple[bool, Optional[str]]:
    banned, until = is_banned(uid)
    if banned:
        return False, f"Заблокирован до {until if until else 'навсегда'}"
    role = get_role(uid)
    limit = ROLE_LIMITS.get(role, ROLE_LIMITS["default"])
    if limit is None:
        return True, None
    cnt = user_daily_count(uid)
    if cnt >= limit:
        return False, f"Превышен дневной лимит ({limit}) для роли {role}"
    return True, None

def is_banned(uid:int) -> Tuple[bool, Optional[str]]:
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT until_ts FROM bans WHERE user_id = ?", (uid,))
        r = cur.fetchone()
        conn.close()
        if not r:
            return False, None
        until = r[0]
        if until and datetime.now() >= datetime.fromisoformat(until):
            return False, None
        return True, until
    except Exception:
        logger.exception("is_banned")
        return False, None

def impose_ban(uid:int, by:int, until_iso:Optional[str], reason:Optional[str]=None) -> bool:
    try:
        prev_role = get_role(uid)
        try:
            set_role(uid, "default", appointed_by=by)
        except Exception:
            pass
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO bans (user_id, banned_by, reason, until_ts, prev_role, created_at) VALUES (?, ?, ?, ?, ?, ?)", (uid, by, reason, until_iso, prev_role, datetime.now().isoformat()))
        conn.commit()
        conn.close()
        return True
    except Exception:
        logger.exception("impose_ban")
        return False

def restore_role_after_ban(uid:int):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT prev_role FROM bans WHERE user_id = ?", (uid,))
        r = cur.fetchone()
        conn.close()
        if not r:
            return
        prev = r[0]
        if prev and prev != "default":
            set_role(uid, prev, appointed_by=0)
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("DELETE FROM bans WHERE user_id = ?", (uid,))
        conn.commit()
        conn.close()
        try:
            asyncio.create_task(bot.send_message(uid, "✅ Ваша роль восстановлена после окончания бана."))
        except Exception:
            pass
    except Exception:
        logger.exception("restore_role_after_ban")

def parse_duration(s:str) -> Optional[str]:
    s = s.strip().lower()
    try:
        if s in ("perm","permanent"):
            return None
        num = int(''.join(ch for ch in s if ch.isdigit()))
        unit = ''.join(ch for ch in s if ch.isalpha())
        if unit == "m":
            return (datetime.now() + timedelta(minutes=num)).isoformat()
        if unit == "h":
            return (datetime.now() + timedelta(hours=num)).isoformat()
        if unit == "d":
            return (datetime.now() + timedelta(days=num)).isoformat()
        if unit == "w":
            return (datetime.now() + timedelta(weeks=num)).isoformat()
        if unit in ("mo","month"):
            return (datetime.now() + timedelta(days=30*num)).isoformat()
        if unit == "y":
            return (datetime.now() + timedelta(days=365*num)).isoformat()
        if s.isdigit():
            return (datetime.now() + timedelta(minutes=int(s))).isoformat()
    except Exception:
        pass
    return None

def escape_html(s:Optional[str]) -> str:
    if s is None:
        return ""
    return html.escape(str(s))

def build_main_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.add(InlineKeyboardButton(text="📝 Новое предложение", callback_data="new_post"))
    kb.add(InlineKeyboardButton(text="📁 Мои посты", callback_data="my_posts"))
    kb.row(InlineKeyboardButton(text="📋 Правила", callback_data="rules"), InlineKeyboardButton(text="ℹ️ Помощь", callback_data="help"))
    kb.row(InlineKeyboardButton(text="👨‍💻 Разработчик", callback_data="dev_info"), InlineKeyboardButton(text="📣 Канал", callback_data="channel_link"))
    kb.add(InlineKeyboardButton(text="🧭 Команды", callback_data="commands"))
    kb.adjust(2)
    return kb.as_markup()

def categories_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    for key, label in CATEGORIES:
        kb.add(InlineKeyboardButton(text=label, callback_data=f"category_{key}"))
    kb.add(InlineKeyboardButton(text="❌ Отмена", callback_data="cancel"))
    kb.adjust(2)
    return kb.as_markup()

def confirm_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.row(InlineKeyboardButton(text="✅ Отправить", callback_data="confirm_send"), InlineKeyboardButton(text="✏️ Редактировать", callback_data="edit_post"))
    kb.row(InlineKeyboardButton(text="⏰ Отложить", callback_data="schedule_post"), InlineKeyboardButton(text="❌ Отменить", callback_data="cancel"))
    kb.adjust(2)
    return kb.as_markup()

def mod_kb_two(pid:int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="✅ Одобрить", callback_data=f"approve_{pid}"), InlineKeyboardButton(text="❌ Отклонить", callback_data=f"reject_{pid}")]])

def users_page_kb(items: List[Tuple[str,str]], prefix: str, page:int, per_page:int=10) -> InlineKeyboardMarkup:
    total = (len(items) + per_page -1)//per_page if items else 1
    page = max(0, min(page, total-1))
    start = page*per_page
    end = start + per_page
    rows = []
    for uid_str,label in items[start:end]:
        rows.append([InlineKeyboardButton(text=label, callback_data=f"{prefix}_u_{uid_str}")])
    nav = []
    if page>0: nav.append(InlineKeyboardButton(text="⬅️", callback_data=f"{prefix}_page_{page-1}"))
    nav.append(InlineKeyboardButton(text=f"{page+1}/{total}", callback_data="noop"))
    if page<total-1: nav.append(InlineKeyboardButton(text="➡️", callback_data=f"{prefix}_page_{page+1}"))
    rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔄 Обновить", callback_data=f"{prefix}_refresh_{page}"), InlineKeyboardButton(text="❌ Закрыть", callback_data=f"{prefix}_close")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def banlist_kb(items: List[Tuple[int,str,str]], prefix:str, page:int, per_page:int=8) -> InlineKeyboardMarkup:
    total = (len(items) + per_page -1)//per_page if items else 1
    page = max(0, min(page, total-1))
    start = page*per_page; end = start+per_page
    rows = []
    for uid, fake, until in items[start:end]:
        label = f"{fake} — до {until if until else 'навсегда'}"
        rows.append([InlineKeyboardButton(text=label, callback_data=f"{prefix}_info_{uid}"), InlineKeyboardButton(text="⛔ Разбанить", callback_data=f"{prefix}_unban_{uid}")])
    nav = []
    if page>0: nav.append(InlineKeyboardButton(text="⬅️", callback_data=f"{prefix}_page_{page-1}"))
    nav.append(InlineKeyboardButton(text=f"{page+1}/{total}", callback_data="noop"))
    if page<total-1: nav.append(InlineKeyboardButton(text="➡️", callback_data=f"{prefix}_page_{page+1}"))
    rows.append(nav)
    rows.append([InlineKeyboardButton(text="🔄 Обновить", callback_data=f"{prefix}_refresh_{page}"), InlineKeyboardButton(text="❌ Закрыть", callback_data=f"{prefix}_close")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def save_post(user_id:int, category:str, text:str, photo:Optional[str], video:Optional[str], animation:Optional[str], status:str, scheduled_at:Optional[str], needs_moderation:int) -> Optional[int]:
    try:
        is_urgent = 1 if category == "urgent" else 0
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("INSERT INTO posts (user_id, category, text, photo, video, animation, status, created_at, scheduled_at, is_urgent, needs_moderation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (user_id, category, text, photo, video, animation, status, datetime.now().isoformat(), scheduled_at, is_urgent, needs_moderation))
        pid = cur.lastrowid
        conn.commit()
        conn.close()
        add_post_to_user(user_id, pid)
        return pid
    except Exception:
        logger.exception("save_post")
        return None

def get_post(pid:int) -> Optional[Dict[str,Any]]:
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT id, user_id, category, text, photo, video, animation, status, created_at, scheduled_at, moderated_by, moderated_at, is_urgent, needs_moderation FROM posts WHERE id = ?", (pid,))
        r = cur.fetchone()
        conn.close()
        if not r:
            return None
        return {"id":r[0],"user_id":r[1],"category":r[2],"text":r[3],"photo":r[4],"video":r[5],"animation":r[6],"status":r[7],"created_at":r[8],"scheduled_at":r[9],"moderated_by":r[10],"moderated_at":r[11],"is_urgent":r[12],"needs_moderation":r[13]}
    except Exception:
        logger.exception("get_post")
        return None

def update_post(pid:int, **kwargs):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        fields = ", ".join([f"{k} = ?" for k in kwargs.keys()])
        vals = list(kwargs.values()); vals.append(pid)
        cur.execute(f"UPDATE posts SET {fields} WHERE id = ?", vals)
        conn.commit()
        conn.close()
    except Exception:
        logger.exception("update_post")

def get_pending_posts(limit:int=50) -> List[Dict[str,Any]]:
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT id, user_id, category, text, photo, video, animation, created_at, is_urgent FROM posts WHERE (status='pending' OR (status='scheduled' AND needs_moderation=1)) ORDER BY CASE WHEN is_urgent=1 THEN 0 ELSE 1 END, created_at LIMIT ?", (limit,))
        rows = cur.fetchall()
        conn.close()
        out=[]
        for r in rows:
            out.append({"id":r[0],"user_id":r[1],"category":r[2],"text":r[3],"photo":r[4],"video":r[5],"animation":r[6],"created_at":r[7],"is_urgent":r[8]})
        return out
    except Exception:
        logger.exception("get_pending_posts")
        return []

def record_mod_message(post_id:int, chat_id:int, message_id:int):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("INSERT INTO mod_messages (post_id, chat_id, message_id) VALUES (?, ?, ?)", (post_id, chat_id, message_id))
        conn.commit()
        conn.close()
    except Exception:
        logger.exception("record_mod_message")

def clear_mod_messages(post_id:int):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT chat_id, message_id FROM mod_messages WHERE post_id = ?", (post_id,))
        rows = cur.fetchall()
        for chat_id, message_id in rows:
            try:
                asyncio.create_task(bot.edit_message_reply_markup(chat_id=chat_id, message_id=message_id, reply_markup=None))
            except Exception:
                pass
        cur.execute("DELETE FROM mod_messages WHERE post_id = ?", (post_id,))
        conn.commit()
        conn.close()
    except Exception:
        logger.exception("clear_mod_messages")

def templates_get(cat:str) -> Optional[str]:
    path = os.path.join(CONFIG_DIR, "templates.json")
    if os.path.exists(path):
        try:
            j = json.load(open(path, "r", encoding="utf-8"))
            return j.get(cat)
        except Exception:
            logger.exception("templates_get")
    return None

async def publish_to_channel(pid:int) -> bool:
    post = get_post(pid)
    if not post:
        return False
    try:
        tpl = templates_get(post["category"])
        if tpl:
            text = tpl.format(text=post["text"])
        else:
            label = dict(CATEGORIES).get(post["category"], post["category"])
            text = f"{label}\n\n{post['text']}"
        if post.get("is_urgent"):
            text = "🚨 СРОЧНОЕ\n\n" + text
        safe = escape_html(text)
        if post.get("photo"):
            sent = await bot.send_photo(chat_id=CHANNEL_ID, photo=post["photo"], caption=safe, parse_mode=ParseMode.HTML)
        elif post.get("animation"):
            sent = await bot.send_animation(chat_id=CHANNEL_ID, animation=post["animation"], caption=safe, parse_mode=ParseMode.HTML)
        elif post.get("video"):
            sent = await bot.send_video(chat_id=CHANNEL_ID, video=post["video"], caption=safe, parse_mode=ParseMode.HTML)
        else:
            sent = await bot.send_message(chat_id=CHANNEL_ID, text=safe, parse_mode=ParseMode.HTML)
        if sent:
            mid = getattr(sent, "message_id", None)
            update_post(pid, channel_message_id=mid, status="approved")
            return True
    except Exception:
        logger.exception("publish_to_channel")
    return False

@dp.message(Command("start"))
async def cmd_start(m: types.Message):
    uid = m.from_user.id
    ensure_user_file(uid, m.from_user)
    text = f"<b>👋 Привет! Это {escape_html(BOT_TITLE)}</b>\n\n<b>Здесь можно анонимно отправлять объявления, вопросы, объявления о потеряшках и многое другое.</b>\n\n📌 Нажми «📝 Новое предложение», чтобы создать пост; «📁 Мои посты» — посмотреть свои публикации; «📋 Правила» — ознакомиться с правилами сообщества. Удачи! 🤝"
    kb = build_main_kb()
    logger.info(f"/start от {uid}")
    if START_IMAGE_URL:
        try:
            await m.answer_photo(photo=START_IMAGE_URL, caption=text, parse_mode=ParseMode.HTML, reply_markup=kb)
            return
        except Exception:
            pass
    await m.answer(text, parse_mode=ParseMode.HTML, reply_markup=kb)

@dp.callback_query(F.data == "dev_info")
async def cb_dev(callback: types.CallbackQuery):
    txt = "5Д - Замякин Арсений и его студия разработчики\nDark Dev\nby haker_one"
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Он самый 🔗", url="https://t.me/haker_one")],[InlineKeyboardButton(text="Студия разработки", url="https://t.me/Dark_Atelier")]])
    await callback.message.answer(txt, reply_markup=kb)
    await callback.answer()

@dp.callback_query(F.data == "channel_link")
async def cb_channel(callback: types.CallbackQuery):
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Открыть канал", url=f"https://t.me/{CHANNEL_ID.lstrip('@')}")]])
    await callback.message.answer("Канал подслушано N18", reply_markup=kb)
    await callback.answer()

@dp.callback_query(F.data == "new_post")
async def cb_new_post(callback: types.CallbackQuery, state: FSMContext):
    uid = callback.from_user.id
    ensure_user_file(uid, callback.from_user)
    ok, reason = allowed_to_post(uid)
    if not ok:
        await callback.message.answer(f"🚫 {escape_html(reason)}")
        await callback.answer()
        return
    await callback.message.answer("📂 Выберите категорию:", reply_markup=categories_kb())
    await state.set_state(States.waiting_for_category)
    await callback.answer()

@dp.callback_query(F.data.startswith("category_"))
async def cb_category(callback: types.CallbackQuery, state: FSMContext):
    cat = callback.data.split("_",1)[1]
    await state.update_data(category=cat)
    label = dict(CATEGORIES).get(cat, cat)
    await callback.message.answer(f"Категория: {escape_html(label)}\n✍️ Отправьте текст поста")
    await state.set_state(States.waiting_for_text)
    await callback.answer()

@dp.message(States.waiting_for_text)
async def msg_text(m: types.Message, state: FSMContext):
    uid = m.from_user.id
    ensure_user_file(uid, m.from_user)
    await state.update_data(text=m.text or "")
    await state.set_state(States.waiting_for_media)
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⏭ Пропустить", callback_data="skip_media")]])
    await m.answer("📎 Добавьте фото/video/gif (опционально) или нажмите Пропустить", reply_markup=kb)

@dp.callback_query(F.data == "skip_media")
async def cb_skip_media(callback: types.CallbackQuery, state: FSMContext):
    await state.update_data(photo=None, video=None, animation=None)
    await preview_and_options(callback.message, state)
    await callback.answer()

@dp.message(F.photo, States.waiting_for_media)
async def msg_photo(m: types.Message, state: FSMContext):
    file_id = m.photo[-1].file_id
    await state.update_data(photo=file_id, video=None, animation=None)
    await preview_and_options(m, state)

@dp.message(F.video, States.waiting_for_media)
async def msg_video(m: types.Message, state: FSMContext):
    file_id = m.video.file_id
    await state.update_data(video=file_id, photo=None, animation=None)
    await preview_and_options(m, state)

@dp.message(F.animation, States.waiting_for_media)
async def msg_animation(m: types.Message, state: FSMContext):
    file_id = m.animation.file_id
    await state.update_data(animation=file_id, photo=None, video=None)
    await preview_and_options(m, state)

async def preview_and_options(m: types.Message, state: FSMContext):
    data = await state.get_data()
    cat = data.get("category")
    txt = data.get("text","")
    photo = data.get("photo")
    video = data.get("video")
    animation = data.get("animation")
    label = dict(CATEGORIES).get(cat, cat)
    preview = f"📋 <b>Предпросмотр</b>\nКатегория: <i>{escape_html(label)}</i>\n\n{escape_html(txt)}"
    await state.set_state(States.waiting_for_confirm)
    kb = confirm_kb()
    try:
        if photo:
            await m.answer_photo(photo=photo, caption=preview, parse_mode=ParseMode.HTML, reply_markup=kb)
        elif animation:
            await m.answer_animation(animation=animation, caption=preview, parse_mode=ParseMode.HTML, reply_markup=kb)
        elif video:
            await m.answer_video(video=video, caption=preview, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await m.answer(preview, parse_mode=ParseMode.HTML, reply_markup=kb)
    except Exception:
        try:
            if photo:
                await m.answer_photo(photo=photo, caption=preview, reply_markup=kb)
            elif animation:
                await m.answer_animation(animation=animation, caption=preview, reply_markup=kb)
            elif video:
                await m.answer_video(video=video, caption=preview, reply_markup=kb)
            else:
                await m.answer(preview, reply_markup=kb)
        except Exception:
            logger.exception("preview fallback failed")

@dp.callback_query(F.data == "edit_post")
async def cb_edit_post(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("✏️ Отправьте новый текст:")
    await state.set_state(States.waiting_for_text)
    await callback.answer()

@dp.callback_query(F.data == "schedule_post")
async def cb_schedule(callback: types.CallbackQuery, state: FSMContext):
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="1ч", callback_data="sched_60"), InlineKeyboardButton(text="6ч", callback_data="sched_360")],[InlineKeyboardButton(text="1д", callback_data="sched_1440"), InlineKeyboardButton(text="7д", callback_data="sched_10080")],[InlineKeyboardButton(text="30д", callback_data="sched_43200")]])
    await callback.message.answer("Выберите отложку или введите вручную минуты", reply_markup=kb)
    await state.set_state(States.waiting_for_schedule)
    await callback.answer()

@dp.callback_query(F.data.startswith("sched_"), States.waiting_for_schedule)
async def cb_sched_quick(callback: types.CallbackQuery, state: FSMContext):
    arg = callback.data.split("_",1)[1]
    try:
        minutes = int(arg)
        scheduled = (datetime.now() + timedelta(minutes=minutes)).isoformat()
    except Exception:
        scheduled = None
    data = await state.get_data()
    uid = callback.from_user.id
    category = data.get("category"); text = data.get("text",""); photo = data.get("photo"); video = data.get("video"); animation = data.get("animation")
    ok, reason = allowed_to_post(uid)
    if not ok:
        await callback.message.answer(f"🚫 {escape_html(reason)}")
        await state.clear()
        await callback.answer()
        return
    pid = save_post(uid, category, text, photo, video, animation, "scheduled", scheduled, 1)
    if pid:
        await callback.message.answer(f"✅ Пост #{pid} запланирован и отправлен на модерацию.")
        asyncio.create_task(notify_moderators(pid))
    else:
        await callback.message.answer("❌ Ошибка сохранения")
    await state.clear()
    await callback.answer()

@dp.message(States.waiting_for_schedule)
async def msg_sched_manual(m: types.Message, state: FSMContext):
    arg = m.text.strip()
    try:
        if arg.isdigit():
            iso = (datetime.now() + timedelta(minutes=int(arg))).isoformat()
        else:
            iso = datetime.fromisoformat(arg).isoformat()
    except Exception:
        await m.answer("Неправильный формат. Введите минуты или ISO datetime")
        return
    data = await state.get_data()
    uid = m.from_user.id
    category = data.get("category"); text = data.get("text",""); photo = data.get("photo"); video = data.get("video"); animation = data.get("animation")
    ok, reason = allowed_to_post(uid)
    if not ok:
        await m.answer(f"🚫 {escape_html(reason)}")
        await state.clear()
        return
    pid = save_post(uid, category, text, photo, video, animation, "scheduled", iso, 1)
    if pid:
        await m.answer(f"✅ Пост #{pid} запланирован и отправлен на модерацию.")
        asyncio.create_task(notify_moderators(pid))
    else:
        await m.answer("❌ Ошибка")
    await state.clear()

@dp.callback_query(F.data == "cancel")
async def cb_cancel(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.answer("Отмена")
    await callback.answer()

@dp.callback_query(F.data == "confirm_send")
async def cb_confirm_send(callback: types.CallbackQuery, state: FSMContext):
    data = await state.get_data()
    uid = callback.from_user.id
    ok, reason = allowed_to_post(uid)
    if not ok:
        await callback.message.answer(f"🚫 {escape_html(reason)}")
        await state.clear()
        await callback.answer()
        return
    cat = data.get("category"); text = data.get("text",""); photo = data.get("photo"); video = data.get("video"); animation = data.get("animation")
    role = get_role(uid)
    needs_mod = 0 if role in ("admin","tech_admin") else 1
    status = "approved" if role in ("admin","tech_admin") else "pending"
    pid = save_post(uid, cat, text, photo, video, animation, status, None, needs_mod)
    if not pid:
        await callback.message.answer("❌ Ошибка")
        await state.clear()
        await callback.answer()
        return
    increment_user_daily(uid)
    if role in ("admin","tech_admin"):
        okpub = await publish_to_channel(pid)
        if okpub:
            update_post(pid, moderated_by=uid, moderated_at=datetime.now().isoformat())
            await callback.message.answer("✅ Опубликовано")
        else:
            await callback.message.answer("Ошибка публикации")
    else:
        asyncio.create_task(notify_moderators(pid))
        await callback.message.answer("✅ Отправлено на модерацию")
    await state.clear()
    await callback.answer()

async def notify_moderators(pid:int):
    post = get_post(pid)
    if not post:
        return
    uf = read_user(post["user_id"])
    fake = uf.get("fake_name") if uf else None
    real = post["user_id"]
    preview_text = f"🆕 Пост #{post['id']}\nКатегория: {escape_html(post['category'])}\n\n{escape_html(post['text'][:900])}\n\nАвтор: {escape_html(fake or '—')} (ID: <code>{escape_html(str(real))}</code>)"
    admins = list_admin_ids()
    for a in admins:
        try:
            kb = mod_kb_two(pid)
            if post.get("photo"):
                sent = await bot.send_photo(chat_id=a, photo=post["photo"], caption=preview_text, reply_markup=kb, parse_mode=ParseMode.HTML)
            elif post.get("animation"):
                sent = await bot.send_animation(chat_id=a, animation=post["animation"], caption=preview_text, reply_markup=kb, parse_mode=ParseMode.HTML)
            elif post.get("video"):
                sent = await bot.send_video(chat_id=a, video=post["video"], caption=preview_text, reply_markup=kb, parse_mode=ParseMode.HTML)
            else:
                sent = await bot.send_message(chat_id=a, text=preview_text, reply_markup=kb, parse_mode=ParseMode.HTML)
            mid = getattr(sent, "message_id", None)
            if mid:
                record_mod_message(pid, a, mid)
        except Exception:
            logger.exception("notify_moderators send failed")

@dp.callback_query(F.data.startswith("approve_"))
async def cb_approve(callback: types.CallbackQuery):
    try:
        pid = int(callback.data.split("_",1)[1])
    except Exception:
        await callback.answer("Неверный id")
        return
    post = get_post(pid)
    if not post:
        await callback.answer("Пост не найден")
        return
    if post.get("needs_moderation") == 0:
        await callback.answer("Уже обработан")
        return
    role = get_role(callback.from_user.id)
    if role not in ("moderator","admin","tech_admin"):
        await callback.answer("Нет прав")
        return
    update_post(pid, moderated_by=callback.from_user.id, moderated_at=datetime.now().isoformat(), needs_moderation=0)
    if post.get("scheduled_at"):
        update_post(pid, status="scheduled")
        await callback.message.answer(f"Пост #{pid} одобрен. Публикация запланирована на {escape_html(post.get('scheduled_at'))}.")
    else:
        ok = await publish_to_channel(pid)
        if ok:
            update_post(pid, status="approved", moderated_at=datetime.now().isoformat())
            await callback.message.answer(f"Пост #{pid} одобрен и опубликован.")
        else:
            await callback.message.answer("Ошибка публикации")
    clear_mod_messages(pid)
    await callback.answer()

@dp.callback_query(F.data.startswith("reject_"))
async def cb_reject(callback: types.CallbackQuery):
    try:
        pid = int(callback.data.split("_",1)[1])
    except Exception:
        await callback.answer("Неверный id")
        return
    post = get_post(pid)
    if not post:
        await callback.answer("Пост не найден")
        return
    if post.get("needs_moderation") == 0:
        await callback.answer("Уже обработан")
        return
    role = get_role(callback.from_user.id)
    if role not in ("moderator","admin","tech_admin"):
        await callback.answer("Нет прав")
        return
    update_post(pid, status="rejected", moderated_by=callback.from_user.id, moderated_at=datetime.now().isoformat(), needs_moderation=0)
    await callback.message.answer(f"Пост #{pid} отклонён")
    clear_mod_messages(pid)
    await callback.answer()

@dp.callback_query(F.data == "my_posts")
async def cb_my_posts(callback: types.CallbackQuery):
    await show_my_posts(callback.message, callback.from_user.id, 0)
    await callback.answer()

async def show_my_posts(msg: types.Message, uid: int, page: int):
    uf = read_user(uid)
    posts = uf.get("posts", []) if uf else []
    if not posts:
        await msg.answer("У вас нет постов")
        return
    per = 1
    total = (len(posts) + per - 1) // per
    page = max(0, min(page, total - 1))
    pid = posts[page]
    p = get_post(pid)
    if not p:
        await msg.answer("Пост не найден")
        return
    date = format_date_short(p["created_at"])
    txt = f"<b>#{escape_html(str(p['id']))} • {escape_html(p['category'])}</b>\n\n{escape_html(p['text'])}\n\n<i>Дата: {escape_html(date)} • Статус: {escape_html(p['status'])}</i>"
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️", callback_data=f"my_posts_page_{max(0,page-1)}"), InlineKeyboardButton(text=f"{page+1}/{total}", callback_data="noop"), InlineKeyboardButton(text="➡️", callback_data=f"my_posts_page_{min(total-1,page+1)}")],[InlineKeyboardButton(text="❌ Закрыть", callback_data="close_myposts")]])
    try:
        if p.get("photo"):
            await msg.answer_photo(photo=p["photo"], caption=txt, parse_mode=ParseMode.HTML, reply_markup=kb)
        elif p.get("animation"):
            await msg.answer_animation(animation=p["animation"], caption=txt, parse_mode=ParseMode.HTML, reply_markup=kb)
        elif p.get("video"):
            await msg.answer_video(video=p["video"], caption=txt, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await msg.answer(txt, parse_mode=ParseMode.HTML, reply_markup=kb)
    except Exception:
        try:
            await msg.answer(txt, reply_markup=kb)
        except Exception:
            logger.exception("show_my_posts fallback failed")

@dp.callback_query(F.data.startswith("my_posts_page_"))
async def cb_my_posts_page(callback: types.CallbackQuery):
    page = int(callback.data.split("_")[-1])
    await show_my_posts(callback.message, callback.from_user.id, page)
    await callback.answer()

@dp.callback_query(F.data == "close_myposts")
async def cb_close_myposts(callback: types.CallbackQuery):
    await callback.message.answer("Закрыто.")
    await callback.answer()

@dp.callback_query(F.data == "rules")
async def cb_rules(callback: types.CallbackQuery):
    rules = ("📜 <b>Правила</b>\n\n"
             "<b>1)</b> Маты - можно ✅ но не желательно\n"
             "<b>2)</b> Личные данные других публиковать НЕЛЬЗЯ а то я ваши солью.\n"
             "<b>3)</b> Реклама без согласования запрещена.\n"
             "<b>4)</b> Соблюдать правила номер 1, 2, 3\n\n"
             "Нарушения приводят к бану. Спасибо за соблюдение! ✅")
    await callback.message.answer(rules, parse_mode=ParseMode.HTML)
    await callback.answer()

@dp.callback_query(F.data == "help")
async def cb_help(callback: types.CallbackQuery):
    help_text = "ℹ️ <b>Помощь</b>\n\n• 📝 — создать новый пост\n• 📁 — мои посты\n• Правила и Команды в меню\n\nЕсли что-то не работает — напиши в техподержку Dark Heavens @dark_heavens_support_bot."
    await callback.message.answer(help_text, parse_mode=ParseMode.HTML)
    await callback.answer()

@dp.callback_query(F.data == "commands")
@dp.callback_query(F.data == "comands")
async def cb_commands_button(callback: types.CallbackQuery):
    role = get_role(callback.from_user.id)
    logger.info(f"Команды (кнопка) вызваны {callback.from_user.id} роль={role}")
    base = ["<b>🧭 Общие команды</b>", "/start", "/whoami", "/commands"]
    admin_cmds = ["<b>🛠 Админ</b>", "/users", "/banlist", "/user <fake_name>", "/parentset <role> <fake_name>"]
    mod_cmds = ["<b>🔰 Модерация</b>", "/users", "/banlist", "/user <fake_name>"]
    txt_parts = ["<b>Доступные команды</b>"]
    txt_parts += base
    txt_parts.append("")
    if role in ("moderator", "admin", "tech_admin"):
        txt_parts += mod_cmds
        txt_parts.append("")
    if role in ("admin", "tech_admin"):
        txt_parts += admin_cmds
        txt_parts.append("")
    if role == "tech_admin":
        txt_parts.append("Техадмин имеет расширенные права на управление ролями и конфигами - ну он и один он может всё.")
    txt = "\n".join(txt_parts)
    safe_txt = escape_html(txt).replace("&lt;b&gt;", "<b>").replace("&lt;/b&gt;", "</b>").replace("&lt;i&gt;", "<i>").replace("&lt;/i&gt;", "</i>")
    try:
        await callback.message.answer(safe_txt, parse_mode=ParseMode.HTML)
    except Exception:
        try:
            await callback.message.answer(safe_txt)
        except Exception:
            logger.exception("cb_commands_button failed")
    await callback.answer()

@dp.message(Command("comands"))
@dp.message(Command("commands"))
async def cmd_commands(message: types.Message):
    role = get_role(message.from_user.id)
    logger.info(f"/commands вызвана {message.from_user.id} роль={role}")
    base = ["<b>🧭 Общие команды</b>", "/start", "/whoami", "/commands"]
    admin_cmds = ["<b>🛠 Админ</b>", "/users", "/banlist", "/user <fake_name>", "/parentset <role> <fake_name>"]
    mod_cmds = ["<b>🔰 Модерация</b>", "/users", "/banlist", "/user <fake_name>"]
    txt_parts = ["<b>Доступные команды</b>"]
    txt_parts += base
    txt_parts.append("")
    if role in ("moderator", "admin", "tech_admin"):
        txt_parts += mod_cmds
        txt_parts.append("")
    if role in ("admin", "tech_admin"):
        txt_parts += admin_cmds
        txt_parts.append("")
    if role == "tech_admin":
        txt_parts.append("Техадмин имеет расширенные права на управление ролями и конфигами.")
    txt = "\n".join(txt_parts)
    safe_txt = escape_html(txt).replace("&lt;b&gt;", "<b>").replace("&lt;/b&gt;", "</b>").replace("&lt;i&gt;", "<i>").replace("&lt;/i&gt;", "</i>")
    try:
        await message.answer(safe_txt, parse_mode=ParseMode.HTML)
    except Exception:
        try:
            await message.answer(safe_txt)
        except Exception:
            logger.exception("cmd_commands failed")

@dp.message(Command("whoami"))
async def cmd_whoami(m: types.Message):
    uid = m.from_user.id
    ensure_user_file(uid, m.from_user)
    uf = read_user(uid)
    role = get_role(uid)
    fake = uf.get("fake_name") if uf else None
    txt = f"👤 Роль: <b>{escape_html(role)}</b>\n🆔 Фейк-имя: <code>{escape_html(fake or '—')}</code>"
    try:
        await m.answer(txt, parse_mode=ParseMode.HTML)
    except Exception:
        await m.answer(txt)

@dp.message(Command("users"))
async def cmd_users_list(m: types.Message):
    role = get_role(m.from_user.id)
    if role not in ("moderator","admin","tech_admin"):
        await m.answer("❌ Нет доступа"); return
    items=[]
    for fname in sorted(os.listdir(USERS_DIR)):
        if not fname.endswith(".json"): continue
        try:
            uid = int(fname[:-5])
            uf = read_user(uid)
            fake = uf.get("fake_name","—")
            role_badge = ROLE_BADGES.get(uf.get("role","default"), uf.get("role","default"))
            label = f"{fake} · {role_badge}"
            items.append((str(uid), label))
        except Exception:
            continue
    if not items:
        await m.answer("Пользователей нет")
        return
    kb = users_page_kb(items, "users", 0, per_page=8)
    try:
        await m.answer("Список пользователей (нажмите на строку для действий):", reply_markup=kb)
    except Exception:
        await m.answer("Список пользователей (ошибка с клавиатурой)")

@dp.callback_query(F.data.startswith("users_page_"))
async def cb_users_page(callback: types.CallbackQuery):
    page = int(callback.data.split("_")[-1])
    items=[]
    for fname in sorted(os.listdir(USERS_DIR)):
        if not fname.endswith(".json"): continue
        try:
            uid = int(fname[:-5])
            uf = read_user(uid)
            fake = uf.get("fake_name","—")
            role_badge = ROLE_BADGES.get(uf.get("role","default"), uf.get("role","default"))
            label = f"{fake} · {role_badge}"
            items.append((str(uid), label))
        except Exception:
            continue
    kb = users_page_kb(items, "users", page, per_page=8)
    try:
        await callback.message.edit_text("Список пользователей (нажмите на строку для действий):", reply_markup=kb)
    except Exception:
        try:
            await callback.message.answer("Список пользователей (обновлён):", reply_markup=kb)
        except Exception:
            pass
    await callback.answer()

@dp.callback_query(F.data.startswith("users_u_"))
async def cb_users_user(callback: types.CallbackQuery):
    uid_str = callback.data.split("_")[-1]
    try:
        uid = int(uid_str)
    except Exception:
        await callback.answer("Ошибка"); return
    uf = read_user(uid)
    if not uf:
        await callback.answer("Пользователь не найден"); return
    fake = uf.get("fake_name","—")
    real = uf.get("real_name","—")
    role = uf.get("role","default")
    txt = f"👤 <b>{escape_html(fake)}</b>\nРеальное имя: {escape_html(real)}\nРоль: <b>{escape_html(role)}</b>\nПостов: {len(uf.get('posts',[]))}\nID: <code>{escape_html(str(uid))}</code>"
    rows = []
    rows.append([InlineKeyboardButton(text="⛔ Забанить", callback_data=f"users_ban_{uid}")])
    rows.append([InlineKeyboardButton(text="🔧 Назначить роль", callback_data=f"users_assign_{uid}"), InlineKeyboardButton(text="♻️ Сбросить роль", callback_data=f"users_resetrole_{uid}")])
    rows.append([InlineKeyboardButton(text="📄 Посты", callback_data=f"users_posts_{uid}")])
    rows.append([InlineKeyboardButton(text="⬅️ Назад к списку", callback_data="users_page_0")])
    kb = InlineKeyboardMarkup(inline_keyboard=rows)
    try:
        await callback.message.answer(txt, parse_mode=ParseMode.HTML, reply_markup=kb)
    except Exception:
        await callback.message.answer(txt, reply_markup=kb)
    await callback.answer()

@dp.callback_query(F.data.startswith("users_ban_"))
async def cb_users_ban(callback: types.CallbackQuery, state: FSMContext):
    uid = int(callback.data.split("_")[-1])
    await state.update_data(ban_target=uid)
    await state.set_state(States.users_wait_ban_duration)
    await callback.message.answer("Введите длительность бана, например: 10m 2h 1d или 'perm' для вечного")
    await callback.answer()

@dp.message(States.users_wait_ban_duration)
async def msg_users_ban_duration(m: types.Message, state: FSMContext):
    data = await state.get_data()
    target = data.get("ban_target")
    if not target:
        await m.answer("Цель не найдена"); await state.clear(); return
    dur = m.text.strip()
    iso = parse_duration(dur)
    if iso is None and dur not in ("perm","permanent"):
        await m.answer("Неверный формат длительности"); return
    issuer = m.from_user.id
    if not can_ban(issuer, target):
        await m.answer("Нельзя банить этого пользователя"); await state.clear(); return
    ok = impose_ban(target, issuer, iso, reason=f"ban {dur} by ui")
    if ok:
        await m.answer("Пользователь забанен и роль сброшена. Роль восстановится по окончании бана.")
    else:
        await m.answer("Ошибка при бане")
    await state.clear()

@dp.callback_query(F.data.startswith("users_assign_"))
async def cb_users_assign(callback: types.CallbackQuery):
    uid = int(callback.data.split("_")[-1])
    role_issuer = get_role(callback.from_user.id)
    opts=[]
    if role_issuer == "moderator":
        opts=[("trainee","Стажёр"),("default","Обычный (сброс)")]
    elif role_issuer == "admin":
        opts=[("trainee","Стажёр"),("moderator","Модератор"),("default","Обычный (сброс)")]
    elif role_issuer == "tech_admin":
        opts=[("trainee","Стажёр"),("moderator","Модератор"),("admin","Админ"),("default","Обычный (сброс)")]
    else:
        opts=[("default","Обычный (сброс)")]
    rows=[]
    for key,label in opts:
        rows.append([InlineKeyboardButton(text=label, callback_data=f"users_doassign_{uid}_{key}")])
    rows.append([InlineKeyboardButton(text="Отмена", callback_data="users_page_0")])
    kb = InlineKeyboardMarkup(inline_keyboard=rows)
    await callback.message.answer("Выберите роль:", reply_markup=kb)
    await callback.answer()

@dp.callback_query(F.data.startswith("users_doassign_"))
async def cb_users_doassign(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    uid = int(parts[2]); role = parts[3]
    issuer = callback.from_user.id
    set_role(uid, role, appointed_by=issuer)
    await callback.message.answer(f"Роль пользователя установлена: {escape_html(role)}")
    await callback.answer()

@dp.callback_query(F.data.startswith("users_resetrole_"))
async def cb_users_resetrole(callback: types.CallbackQuery):
    uid = int(callback.data.split("_")[-1])
    set_role(uid, "default", appointed_by=callback.from_user.id)
    await callback.message.answer("Роль сброшена до Обычного пользователя")
    await callback.answer()

@dp.callback_query(F.data.startswith("users_posts_"))
async def cb_users_posts(callback: types.CallbackQuery):
    uid = int(callback.data.split("_")[-1])
    uf = read_user(uid)
    posts = uf.get("posts",[]) if uf else []
    if not posts:
        await callback.message.answer("Постов нет"); await callback.answer(); return
    await callback.message.answer("Показываю посты пользователя")
    await show_user_posts(callback.message, uid, 0)
    await callback.answer()

async def show_user_posts(m: types.Message, uid:int, page:int):
    uf = read_user(uid)
    posts = uf.get("posts",[]) if uf else []
    if not posts:
        await m.answer("Постов нет"); return
    per=1
    total=(len(posts)+per-1)//per
    page = max(0,min(page,total-1))
    pid = posts[page]
    p = get_post(pid)
    if not p:
        await m.answer("Пост не найден"); return
    date = format_date_short(p.get("created_at"))
    txt = f"<b>#{p['id']} • {escape_html(p['category'])}</b>\n\n{escape_html(p['text'])}\n\n<i>Дата: {escape_html(date)} • Статус: {escape_html(p['status'])}</i>"
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⬅️", callback_data=f"posts_page_{uid}_{max(0,page-1)}"),
        InlineKeyboardButton(text=f"{page+1}/{total}", callback_data="noop"),
        InlineKeyboardButton(text="➡️", callback_data=f"posts_page_{uid}_{min(total-1,page+1)}")
    ], [InlineKeyboardButton(text="Назад", callback_data="users_page_0")]])
    try:
        if p.get("photo"):
            await m.answer_photo(photo=p["photo"], caption=txt, parse_mode=ParseMode.HTML, reply_markup=kb)
        elif p.get("animation"):
            await m.answer_animation(animation=p["animation"], caption=txt, parse_mode=ParseMode.HTML, reply_markup=kb)
        elif p.get("video"):
            await m.answer_video(video=p["video"], caption=txt, parse_mode=ParseMode.HTML, reply_markup=kb)
        else:
            await m.answer(txt, parse_mode=ParseMode.HTML, reply_markup=kb)
    except Exception:
        try:
            await m.answer(txt, reply_markup=kb)
        except Exception:
            pass

@dp.callback_query(F.data.startswith("posts_page_"))
async def cb_posts_page(callback: types.CallbackQuery):
    parts = callback.data.split("_")
    uid = int(parts[2]); page = int(parts[3])
    await show_user_posts(callback.message, uid, page)
    await callback.answer()

@dp.message(Command("ban"))
async def cmd_ban(m: types.Message):
    role = get_role(m.from_user.id)
    if role not in ("moderator","admin","tech_admin"):
        await m.answer("❌ Нет доступа"); return
    args = m.get_args().split()
    if len(args) < 2:
        await m.answer("Использование: /ban <fake_name> <duration> (10m/2h/1d/perm)"); return
    fake = args[0].strip().lower(); dur = args[1].strip()
    target=None
    for fname in os.listdir(USERS_DIR):
        if not fname.endswith(".json"): continue
        try:
            uid=int(fname[:-5])
            uf = read_user(uid)
            if (uf.get("fake_name") or "").lower() == fake:
                target=uid; break
        except Exception:
            continue
    if not target:
        await m.answer("Пользователь не найден"); return
    if not can_ban(m.from_user.id, target):
        await m.answer("Нельзя банить этого пользователя"); return
    iso = parse_duration(dur)
    if iso is None and dur not in ("perm","permanent"):
        await m.answer("Неверная длительность"); return
    ok = impose_ban(target, m.from_user.id, iso, reason=f"ban {dur}")
    if ok:
        await m.answer("✅ Пользователь забанен. Роль временно сброшена.")
    else:
        await m.answer("Ошибка при бане")

@dp.message(Command("banlist"))
async def cmd_banlist(m: types.Message):
    role = get_role(m.from_user.id)
    if role not in ("moderator","admin","tech_admin"):
        await m.answer("❌ Нет доступа"); return
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT user_id, until_ts, prev_role FROM bans ORDER BY created_at DESC")
        rows = cur.fetchall()
        conn.close()
        if not rows:
            await m.answer("✅ Нет забаненных")
            return
        items=[]
        for uid, until, prev in rows:
            uf = read_user(uid)
            fake = uf.get("fake_name") if uf else str(uid)
            items.append((uid, fake, until))
        kb = banlist_kb(items, "banlist", 0, per_page=6)
        await m.answer("Список забаненных (нажмите «Разбанить» напротив):", reply_markup=kb)
    except Exception:
        logger.exception("banlist")
        await m.answer("Ошибка получения списка")

@dp.callback_query(F.data.startswith("banlist_page_"))
async def cb_banlist_page(callback: types.CallbackQuery):
    page = int(callback.data.split("_")[-1])
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT user_id, until_ts FROM bans ORDER BY created_at DESC")
    rows = cur.fetchall()
    conn.close()
    items=[]
    for uid, until in rows:
        uf = read_user(uid)
        fake = uf.get("fake_name") if uf else str(uid)
        items.append((uid, fake, until))
    kb = banlist_kb(items, "banlist", page, per_page=6)
    try:
        await callback.message.edit_text("Список забаненных (нажмите «Разбанить» напротив):", reply_markup=kb)
    except Exception:
        try:
            await callback.message.answer("Обновлён список забаненных:", reply_markup=kb)
        except Exception:
            pass
    await callback.answer()

@dp.callback_query(F.data.startswith("banlist_unban_"))
async def cb_banlist_unban(callback: types.CallbackQuery):
    uid = int(callback.data.split("_")[-1])
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT prev_role FROM bans WHERE user_id = ?", (uid,))
        r = cur.fetchone()
        prev = r[0] if r else None
        cur.execute("DELETE FROM bans WHERE user_id = ?", (uid,))
        conn.commit()
        conn.close()
        if prev and prev != "default":
            set_role(uid, prev, appointed_by=callback.from_user.id)
        await callback.message.answer("✅ Пользователь разбанен и роль восстановлена (если была).")
    except Exception:
        logger.exception("banlist_unban")
        await callback.message.answer("Ошибка при разбане")
    await callback.answer()

@dp.callback_query(F.data.startswith("banlist_unban_"))
async def cb_banlist_unban_alias(callback: types.CallbackQuery):
    await cb_banlist_unban(callback)

def format_date_short(iso:Optional[str]) -> str:
    if not iso:
        return ""
    try:
        return datetime.fromisoformat(iso).strftime("%Y.%m.%d")
    except Exception:
        return iso

async def scheduled_worker():
    while True:
        try:
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            now = datetime.now().isoformat()
            cur.execute("SELECT id FROM posts WHERE status='scheduled' AND needs_moderation=0 AND scheduled_at <= ?", (now,))
            rows = cur.fetchall()
            conn.close()
            for r in rows:
                pid = r[0]
                ok = await publish_to_channel(pid)
                if ok:
                    update_post(pid, status="approved", moderated_at=datetime.now().isoformat())
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("SELECT user_id, until_ts FROM bans WHERE until_ts IS NOT NULL")
            rows = cur.fetchall()
            conn.close()
            for uid, until in rows:
                if until and datetime.now() >= datetime.fromisoformat(until):
                    restore_role_after_ban(uid)
            await asyncio.sleep(20)
        except Exception:
            logger.exception("scheduled_worker")
            await asyncio.sleep(60)

def can_ban(issuer:int, target:int) -> bool:
    rank = {"default":0,"trainee":1,"moderator":2,"admin":3,"tech_admin":4}
    r1 = get_role(issuer); r2 = get_role(target)
    if r1 == "tech_admin": return True
    return rank.get(r1,0) > rank.get(r2,0)

async def on_startup():
    logger.info("Бот запущен (startup)")
    migrate_db()

async def on_shutdown():
    try:
        await bot.session.close()
    except Exception:
        pass

async def main():
    await on_startup()
    task = asyncio.create_task(scheduled_worker())
    try:
        await dp.start_polling(bot, shutdown_callback=on_shutdown)
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Остановка")
    except Exception:
        logger.exception("Fatal")
