import sqlite3
from datetime import datetime
db = "data/main.db"
uid =
role = "tech_admin"  # или "tech_admin"
conn = sqlite3.connect(db)
cur = conn.cursor()
cur.execute("INSERT OR REPLACE INTO admins (user_id, rank, appointed_by, appointed_at) VALUES (?, ?, ?, ?)",
            (uid, role, 0, datetime.now().isoformat()))
conn.commit()
conn.close()
print("Готово")
